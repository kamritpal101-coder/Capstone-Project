# AI Log

I used an AI assistant mainly to help me understand/check the SQL and Pandas parts. I did not use AI as a replacement for checking the results.

## Prompt 1 - SQL

**Role:** SQL tutor

**Context:** I am working on a BigBasket category performance project in SQLite. I have orders, products and category target tables.

**Task:** Help me write/check a SQLite query for monthly category revenue using Delivered orders.

**Constraints:** Use SQLite and `strftime('%Y-%m', order_date)`. Return category, month, order count, total revenue and average revenue.

**Format:** Give the query and explain it briefly.

### What I checked myself
I ran the query on my database. It gave 36 monthly rows and the total revenue was 88282.

## Prompt 2 - Pandas

**Role:** Pandas/data-cleaning tutor

**Context:** My raw order file contains duplicates, inconsistent text, missing amounts and some unusually large amounts.

**Task:** Help me use the IQR method to find the upper fence and cap high Delivered-order amounts.

**Constraints:** Do not replace missing amounts and do not remove the outliers. Use Pandas.

**Format:** Give simple code and explain the calculation.

### What I checked myself
I ran the notebook and checked the IQR calculation and the capped values. I also checked that the duplicate order IDs were reduced to 500 unique orders and that the top category/supplier matched the required cross-check.
