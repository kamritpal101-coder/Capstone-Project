-- 01_foundations.sql

-- 1. SELECT / WHERE: orders from Mumbai
SELECT o.*
FROM orders AS o
JOIN customers AS c ON o.customer_id = c.customer_id
WHERE c.city = 'Mumbai';

-- 2. DISTINCT: every distinct category
SELECT DISTINCT category
FROM products
ORDER BY category;

-- 3. ORDER BY + LIMIT: five highest-value orders
SELECT *
FROM orders
ORDER BY amount_inr DESC
LIMIT 5;

-- 4. Alias (AS): aggregate alias
SELECT COUNT(*) AS total_orders
FROM orders;

-- 5. IN: orders whose payment mode is UPI or Credit Card
SELECT *
FROM orders
WHERE payment_mode IN ('UPI', 'Credit Card');

-- 6. BETWEEN: orders with amount between INR 100 and INR 500
SELECT *
FROM orders
WHERE amount_inr BETWEEN 100 AND 500;

-- 7. NOT BETWEEN: orders outside INR 100 to INR 500
SELECT *
FROM orders
WHERE amount_inr NOT BETWEEN 100 AND 500;

-- 8. IS NULL: orders with no rating
SELECT *
FROM orders
WHERE rating IS NULL;
