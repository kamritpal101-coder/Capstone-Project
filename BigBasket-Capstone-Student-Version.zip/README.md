# BigBasket Category Performance Diagnostic

## About this project
This is my BigBasket category performance project. I used SQLite, Excel/Google Sheets, Tableau Public and Python/Pandas to check category performance and compare the results between the different parts.

## Files in this repository
- `generate_data.py` - creates the project data
- `bigbasket_capstone.db` - SQLite database
- `orders_raw.csv` - raw/messy order data used for Python
- `products.csv` - product details
- `verify.sql` - basic checks
- `01_foundations.sql` - basic SQL queries
- `02_aggregation_joins.sql` - joins and aggregation
- `03_reporting.sql` - reporting queries
- `monthly_category_revenue.csv` - monthly data used for Excel and Tableau
- `bigbasket_analysis.xlsx` - spreadsheet work
- `analysis.ipynb` - Python/Pandas analysis
- `DATA_STORY.md` - short findings and recommendations
- `ai_log.md` - AI prompts and the checks I did after using them

## Part 1 - SQL
I first generated the database and checked the table counts and order status counts.

The main SQL work is in:
- `01_foundations.sql`
- `02_aggregation_joins.sql`
- `03_reporting.sql`

The monthly result was exported to `monthly_category_revenue.csv`.

Important checks:
- Products: 31
- Customers: 50
- Orders: 500
- Delivered: 434
- Cancelled: 42
- Pending: 24
- Monthly report rows: 36
- Monthly report total revenue: 88282

## Part 2 - Spreadsheet
The Excel workbook is `bigbasket_analysis.xlsx`.

It contains:
- Monthly Data
- Category Targets
- Pivot Table
- Category Summary

I used the monthly CSV from Part 1 and compared the category revenue with the given targets.

## Part 3 - Tableau Public

I used `monthly_category_revenue.csv` for the Tableau dashboard.

**Tableau Public link:** PASTE-YOUR-TABLEAU-PUBLIC-LINK-HERE

The final link should be replaced with my actual published Tableau dashboard before submission.

## Part 4 - Python/Pandas
I used `orders_raw.csv` separately for the cleaning work.

The notebook:
1. Loads the CSV files.
2. Checks the data.
3. Removes duplicate order IDs.
4. Cleans city and category text.
5. Checks missing amounts.
6. Uses IQR to cap unusually high Delivered-order amounts.
7. Creates month and other useful columns.
8. Finds category and supplier revenue.
9. Checks the result against the SQL findings.
10. Makes three Matplotlib charts.

The cleaned analysis gives:
- Top category: Household Essentials
- Top supplier: HomeEssentials Traders

## Data story
The detailed category findings and two recommendations are in `DATA_STORY.md`.

## Re-running the project
Run:

```bash
python3 generate_data.py
```

The data is deterministic, so the fixed seed should not be changed.
