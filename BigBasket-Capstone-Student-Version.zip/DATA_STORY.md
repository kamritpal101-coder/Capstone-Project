# BigBasket Category Performance - My Findings

After comparing the delivered revenue with the category targets, these were the results:

| Category | Revenue | Target | Status |
|---|---:|---:|---|
| Household Essentials | ₹21,715 | ₹17,000 | Above Target |
| Personal Care | ₹16,382 | ₹15,500 | Above Target |
| Bakery | ₹15,410 | ₹12,000 | Above Target |
| Dairy & Eggs | ₹14,090 | ₹16,500 | Below Target - Watch |
| Snacks & Beverages | ₹10,895 | ₹13,000 | Below Target - Critical |
| Fruits & Vegetables | ₹9,790 | ₹12,000 | Below Target - Critical |

## What I noticed

Household Essentials has the highest revenue and is above its target. Personal Care and Bakery are also above target.

Dairy & Eggs is below target, but its gap is smaller than the two critical categories.

Snacks & Beverages and Fruits & Vegetables need more attention because both are below their targets.

## Recommendations

1. I would first review **Snacks & Beverages**, because its revenue is ₹2,105 below the target of ₹13,000. The product mix and promotional activity could be checked.

2. I would also review **Fruits & Vegetables**, which is ₹2,210 below its ₹12,000 target. Checking product availability and supplier performance would be a useful next step.
